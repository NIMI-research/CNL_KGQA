import json
import fire
import torch
from transformers import LlamaTokenizer
from peft import PeftModel
from transformers import LlamaForCausalLM
import time

def create_prompt(path):
    inference_list = []
    with open(path, "r") as outfile:
        prompt_data = json.load(outfile)
    for data in prompt_data:
        if data.get("instruction") is not None:
            completed_prompt =f"Below is an instruction that describes a task. Write a response that appropriately completes the request.\n\n### Instruction:\n{data.get('instruction')}\n\n### Input:\n{data.get('input')}\n\n### Response:"
            print(completed_prompt)
            inference_list.append(completed_prompt)
    return inference_list

def load_model(model_name, quantization):
    model = LlamaForCausalLM.from_pretrained(
        model_name,
        return_dict=True,
        load_in_8bit=quantization,
        device_map="auto",
        low_cpu_mem_usage=True,
        offload_folder=".",
    )
    return model

def load_peft_model(model, peft_model):
    print(f"I am loading PEFT Model.")
    peft_model = PeftModel.from_pretrained(model, peft_model,offload_dir="")
    return peft_model

def run_inference(
        model_name,
        peft_model: str=None,
        quantization: bool=False,
        max_new_tokens = 300,
        seed: int=42,
        do_sample: bool=True,
        min_length: int=None,
        use_cache: bool = True,
        # [optional] Whether or not the model should use the past last key/values attentions Whether or not the model should use the past last key/values attentions (if applicable to the model) to speed up decoding.
        top_p: float = 1.0,
        # [optional] If set to float < 1, only the smallest set of most probable tokens with probabilities that add up to top_p or higher are kept for generation.
        temperature: float = 1.0,  # [optional] The value used to modulate the next token probabilities.
        top_k: int = 50,  # [optional] The number of highest probability vocabulary tokens to keep for top-k-filtering.
        repetition_penalty: float = 1.0,  # The parameter for repetition penalty. 1.0 means no penalty.
        length_penalty: int = 1,
        # [optional] Exponential penalty to the length that is used with beam-based generation.
        inference_file_path : str = "/data//path/inference_file",
        save_result_path: str = "/results/path/to/save",
        **kwargs
):
    torch.cuda.manual_seed(seed)
    torch.manual_seed(seed)
    model = load_model(model_name, quantization)
    tokenizer = LlamaTokenizer.from_pretrained(model_name)
    tokenizer.add_special_tokens(
        {

            "pad_token": "<PAD>",
        }
    )
    if peft_model:
        model = load_peft_model(model, peft_model)

    model.eval()
    inference_data = create_prompt(inference_file_path)
    output_response = []
    for data in inference_data:
        batch = tokenizer(data, return_tensors="pt")
        batch = {k: v.to("cuda") for k, v in batch.items()}
        start = time.perf_counter()
        with torch.no_grad():
            outputs = model.generate(
                **batch,
                max_new_tokens=max_new_tokens,
                do_sample=do_sample,
                top_p=top_p,
                temperature=temperature,
                min_length=min_length,
                use_cache=use_cache,
                top_k=top_k,
                repetition_penalty=repetition_penalty,
                length_penalty=length_penalty,
                **kwargs
            )
        e2e_inference_time = (time.perf_counter() - start) * 1000
        print(f"the inference time is {e2e_inference_time} ms")
        output_text = tokenizer.decode(outputs[0], skip_special_tokens=True)
        print(output_text)
        output_response.append(output_text)
    with open(save_result_path, "w") as outfile:
        json.dump(output_response,outfile)


if __name__ == "__main__":
    fire.Fire(run_inference)